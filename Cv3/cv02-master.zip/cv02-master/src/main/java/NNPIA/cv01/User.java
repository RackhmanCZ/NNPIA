package NNPIA.cv01;


import lombok.*;

@Value
public class User {
    String userName;
    String password;
}
