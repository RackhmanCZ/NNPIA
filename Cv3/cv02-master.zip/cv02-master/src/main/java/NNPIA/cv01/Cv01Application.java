package NNPIA.cv01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cv01Application {

	public static void main(String[] args) {
		SpringApplication.run(Cv01Application.class, args);
	}

}
