package com.example.cv1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Cv1Application {

	public static void main(String[] args) {
		SpringApplication.run(Cv1Application.class, args);
	}

}
